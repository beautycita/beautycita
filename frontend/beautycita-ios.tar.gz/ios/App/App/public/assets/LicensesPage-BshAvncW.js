import{j as e}from"./utils-2G-ni3Pq.js";import{r}from"./vendor-DLBR3Zwv.js";import{P as x}from"./PageHero-C2CcwL21.js";import{u as p,G as l,k as c}from"./index-B8ZpDeSk.js";import"./maps-DHRwxvE9.js";import{m as o}from"./ui-D69ILwRo.js";import{F as m}from"./CodeBracketIcon-BGIClF-2.js";import{F as u}from"./ChevronDownIcon-D3BTBUes.js";import"./router-CfabZPpV.js";import"./forms-CZVvqbzG.js";const L=()=>{const{t:f}=p(),[t,n]=r.useState(!1),[s,d]=r.useState(null);r.useEffect(()=>{const i=localStorage.getItem("darkMode")==="true";n(i);const a=()=>{n(localStorage.getItem("darkMode")==="true")};return window.addEventListener("storage",a),()=>window.removeEventListener("storage",a)},[]);const h=[{name:"React",version:"18.2.0",license:"MIT License",description:"A JavaScript library for building user interfaces",gradient:"from-cyan-500 to-blue-600",fullText:`MIT License

Copyright (c) Meta Platforms, Inc. and affiliates.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.`},{name:"Tailwind CSS",version:"3.3.0",license:"MIT License",description:"A utility-first CSS framework for rapid UI development",gradient:"from-teal-500 to-cyan-600",fullText:`MIT License

Copyright (c) Tailwind Labs, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software...`},{name:"Framer Motion",version:"10.16.0",license:"MIT License",description:"A production-ready motion library for React",gradient:"from-pink-500 to-purple-600",fullText:`MIT License

Copyright (c) 2018 Framer B.V.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction...`},{name:"Heroicons",version:"2.0.0",license:"MIT License",description:"Beautiful hand-crafted SVG icons by the makers of Tailwind CSS",gradient:"from-purple-500 to-indigo-600",fullText:`MIT License

Copyright (c) Tailwind Labs, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software")...`},{name:"TypeScript",version:"5.2.0",license:"Apache License 2.0",description:"TypeScript is a language for application-scale JavaScript",gradient:"from-blue-500 to-indigo-600",fullText:`Apache License
Version 2.0, January 2004

Copyright (c) Microsoft Corporation.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License...`},{name:"Vite",version:"4.5.0",license:"MIT License",description:"Next generation frontend tooling",gradient:"from-yellow-500 to-orange-600",fullText:`MIT License

Copyright (c) 2019-present, Yuxi (Evan) You and Vite contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files...`}];return e.jsxs("div",{className:`min-h-screen ${t?"bg-gray-900":"bg-gray-50"}`,children:[e.jsx(x,{title:"Open Source Licenses",subtitle:"We stand on the shoulders of giants - honoring the open source community",gradient:"from-pink-500 via-purple-500 to-blue-500",isDarkMode:t,height:"h-80"}),e.jsx("section",{className:"container mx-auto px-4 max-w-4xl py-16",children:e.jsx(o.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6},viewport:{once:!0},children:e.jsx(l,{gradient:"from-pink-500/10 via-purple-500/10 to-blue-500/10",isDarkMode:t,children:e.jsxs("div",{className:"flex items-start space-x-4",children:[e.jsx(c,{className:"h-8 w-8 text-pink-500 flex-shrink-0 mt-1"}),e.jsxs("div",{children:[e.jsx("h2",{className:`text-2xl font-bold mb-4 ${t?"text-white":"text-gray-900"}`,children:"Built with Open Source"}),e.jsx("p",{className:`leading-relaxed ${t?"text-gray-300":"text-gray-600"}`,children:"BeautyCita is built using amazing open source software. We're grateful to the developers and contributors who make these tools available. This page lists the open source projects we use and their respective licenses."})]})]})})})}),e.jsxs("section",{className:"container mx-auto px-4 max-w-4xl pb-16",children:[e.jsxs(o.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6},viewport:{once:!0},className:"text-center mb-12",children:[e.jsx("h2",{className:`text-3xl md:text-4xl font-bold mb-4 ${t?"text-white":"text-gray-900"}`,children:"Third-Party Licenses"}),e.jsx("p",{className:`text-lg ${t?"text-gray-400":"text-gray-600"}`,children:"Click on any license to view the full text"})]}),e.jsx("div",{className:"space-y-4",children:h.map((i,a)=>e.jsx(o.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6,delay:a*.05},viewport:{once:!0},children:e.jsxs(l,{gradient:`${i.gradient}/10`,isDarkMode:t,children:[e.jsx("button",{onClick:()=>d(s===a?null:a),className:"w-full text-left",children:e.jsxs("div",{className:"flex items-start justify-between",children:[e.jsxs("div",{className:"flex items-start space-x-4 flex-1",children:[e.jsx("div",{className:`p-3 rounded-3xl bg-gradient-to-r ${i.gradient} flex-shrink-0`,children:e.jsx(m,{className:"h-6 w-6 text-white"})}),e.jsxs("div",{className:"flex-1",children:[e.jsxs("div",{className:"flex items-center space-x-3 mb-2",children:[e.jsx("h3",{className:`text-xl font-bold ${t?"text-white":"text-gray-900"}`,children:i.name}),e.jsxs("span",{className:`text-xs px-2 py-1 rounded-full ${t?"bg-gray-700 text-gray-300":"bg-gray-200 text-gray-600"}`,children:["v",i.version]}),e.jsx("span",{className:`text-xs px-2 py-1 rounded-full ${i.license.includes("MIT")?"bg-green-100 text-green-700":"bg-blue-100 text-blue-700"}`,children:i.license})]}),e.jsx("p",{className:`text-sm ${t?"text-gray-400":"text-gray-600"}`,children:i.description})]})]}),e.jsx(u,{className:`h-5 w-5 flex-shrink-0 ml-4 transition-transform ${s===a?"rotate-180":""} ${t?"text-gray-400":"text-gray-500"}`})]})}),s===a&&e.jsxs(o.div,{initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},exit:{opacity:0,height:0},transition:{duration:.3},className:"mt-6 pt-6 border-t",style:{borderColor:t?"rgba(255,255,255,0.1)":"rgba(0,0,0,0.1)"},children:[e.jsx("h4",{className:`font-semibold mb-3 ${t?"text-white":"text-gray-900"}`,children:"Full License Text"}),e.jsx("pre",{className:`text-xs leading-relaxed whitespace-pre-wrap font-mono p-4 rounded-full overflow-x-auto ${t?"bg-gray-800 text-gray-300":"bg-gray-100 text-gray-700"}`,children:i.fullText})]})]})},i.name))})]}),e.jsxs("section",{className:"relative py-16 overflow-hidden bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500",children:[e.jsxs("div",{className:"absolute inset-0 overflow-hidden pointer-events-none",children:[e.jsx("div",{className:"absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-3xl blur-3xl"}),e.jsx("div",{className:"absolute bottom-0 left-0 w-96 h-96 bg-white/10 rounded-3xl blur-3xl"})]}),e.jsxs(o.div,{initial:{opacity:0,y:20},whileInView:{opacity:1,y:0},transition:{duration:.6},viewport:{once:!0},className:"container mx-auto max-w-4xl text-center text-white relative z-10 px-4",children:[e.jsx(c,{className:"h-16 w-16 text-white/90 mx-auto mb-6"}),e.jsx("h2",{className:"text-3xl md:text-4xl font-bold mb-6",children:"Support Open Source"}),e.jsx("p",{className:"text-xl mb-8 text-white/90 max-w-2xl mx-auto",children:"These projects make our work possible. Consider supporting them and contributing to the open source community."}),e.jsx("button",{className:"bg-white text-purple-600 hover:bg-gray-100 font-semibold px-8 py-4 rounded-3xl transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105",children:"Learn How to Contribute"})]})]})]})};export{L as default};
